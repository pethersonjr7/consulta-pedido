import datetime

CONFIG = {
    "hub2b": {
        "salonline": {
            "client_id": "UwSjZbV99eZN9sVXkvaIsow20AIciQ",
            "client_secret": "hKDpu93dvUTJMqO83IHk9nV9vSLtFJ",
            "username": "5208devintexcosmeticos(salonline)@hub2b",
            "password": "2qj0wjtqkjvp5yedzxsk",
            "scope": "orders",
            "access_token": None,
            "refresh_token": None,
            "last_refresh": datetime.datetime.min
        },
        "zakat": {
            "client_id": "D3AC0kmMRopGBe6fTYPIv6ANbk9srv27",
            "client_secret": "9aW5iqTRo1J7qbW3dZp49xBAgN1xy80y",
            "username": "6467zakat@integracaoti",
            "password": "jxytj4h0b6hj4ea0z8cm",
            "scope": "orders",
            "access_token": None,
            "refresh_token": None,
            "last_refresh": datetime.datetime.min
        }
    },
    "bseller": {
        "salonline": {
            "api_key": "1A4DB1AD9138205DE063A9F3A8C0E9C3"
        },
        "zakat": {
            "api_key": "36C680C3C350DC83E063A9F3A8C084F7"
        }
    }
}
